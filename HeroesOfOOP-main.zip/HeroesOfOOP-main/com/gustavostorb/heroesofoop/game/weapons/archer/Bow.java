package com.gustavostorb.heroesofoop.game.weapons.archer;

import com.gustavostorb.heroesofoop.api.GameWeapon;

public class Bow extends GameWeapon { // extende a classe GameWeapon

    public Bow() { // criação da classe do arco junto com seu nome e atributos
        super("Arco Longo", 12.0, 13.0);
    }
}
