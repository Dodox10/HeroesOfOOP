package com.gustavostorb.heroesofoop.game.weapons.archer;

import com.gustavostorb.heroesofoop.api.GameWeapon;

public class Crossbow extends GameWeapon { // extende a classe GameWeapon

    public Crossbow() { // criação da classe da balestra junto com seu nome e atributos
        super("Balestra", 15.0, 10.0);
    }

}
