package com.gustavostorb.heroesofoop.game.weapons.warrior;

import com.gustavostorb.heroesofoop.api.GameWeapon;

public class Axe extends GameWeapon { // extende a classe GameWeapon

    public Axe() { // criação da classe do machado junto com seu nome e atributos
        super("Machado", 17.0, 8.0);
    }
}
