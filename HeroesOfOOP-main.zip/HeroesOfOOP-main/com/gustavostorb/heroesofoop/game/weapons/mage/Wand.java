package com.gustavostorb.heroesofoop.game.weapons.mage;

import com.gustavostorb.heroesofoop.api.GameWeapon;

public class Wand extends GameWeapon { // extende a classe GameWeapon

    public Wand() { // criação da classe do varinha junto com seu nome e atributos
        super("Varinha", 16.0, 9.0);
    }
}
