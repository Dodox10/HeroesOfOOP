package com.gustavostorb.heroesofoop.game.weapons.mage;

import com.gustavostorb.heroesofoop.api.GameWeapon;

public class Staff extends GameWeapon { // extende a classe GameWeapon

    public Staff() { // criação da classe do cajado junto com seu nome e atributos
        super("Cajado", 13.0, 12.0);
    }
}
