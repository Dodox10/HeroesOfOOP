package com.gustavostorb.heroesofoop.api;

public abstract class GameMenu<T> { // clase abstrata para utilizar o execute em outras funções

    public abstract T execute();

}
