package com.gustavostorb.heroesofoop.api;

public enum GameCharType { // enum (enumeração) dos personagens incluindo dragão (exemplo 0 = WARRIOR)

    WARRIOR,
    MAGE,
    ARCHER,
    DRAGON

}
